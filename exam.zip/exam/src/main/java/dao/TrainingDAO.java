package dao;

import model.Training;

import java.util.ArrayList;
import java.util.List;

public class TrainingDAO {
    private List<Training> trainings;

    public TrainingDAO() {
        this.trainings = new ArrayList<>();
    }

    public void addTraining(Training training) {
        trainings.add(training);
    }

    public List<Training> getAllTrainings() {
        return trainings;
    }
}
