package dao;

import model.FitnessClub;

public class FitnessClubDAO {
    private FitnessClub fitnessClub;

    public FitnessClubDAO() {
        // Параметри фітнес-клубу можна змінити за потреби
        this.fitnessClub = new FitnessClub("Gym Style", "8:00 - 22:00", "www.gymstyle.com.ua");
    }

    public FitnessClub getFitnessClub() {
        return fitnessClub;
    }
}
