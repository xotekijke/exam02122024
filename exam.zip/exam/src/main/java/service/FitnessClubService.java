package service;

import dao.FitnessClubDAO;
import model.FitnessClub;

public class FitnessClubService {
    private FitnessClubDAO fitnessClubDAO;

    public FitnessClubService() {
        fitnessClubDAO = new FitnessClubDAO();
    }

    public void displayClubInfo() {
        FitnessClub club = fitnessClubDAO.getFitnessClub();
        System.out.println("Fitness club info: ");
        System.out.println(club);
    }
}
