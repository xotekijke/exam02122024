package service;

import dao.TrainingDAO;
import model.Training;

public class TrainingService {
    private final TrainingDAO trainingDAO;

    public TrainingService() {
        this.trainingDAO = new TrainingDAO();
    }

    public void addTraining(String name, double dailyPrice, double weeklyPrice, double monthlyPrice) {
        Training training = new Training(name, dailyPrice, weeklyPrice, monthlyPrice);
        trainingDAO.addTraining(training);
    }

    public void displayAllTrainings() {
        for (Training training : trainingDAO.getAllTrainings()) {
            System.out.println(training);
        }
    }
}
