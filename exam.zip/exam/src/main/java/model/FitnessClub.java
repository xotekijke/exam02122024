package model;

public class FitnessClub {
    private String name;
    private String workingHours;
    private String website;

    public FitnessClub(String name, String workingHours, String website) {
        this.name = name;
        this.workingHours = workingHours;
        this.website = website;
    }

    public String getName() {
        return name;
    }

    public String getWorkingHours() {
        return workingHours;
    }

    public String getWebsite() {
        return website;
    }

    @Override
    public String toString() {
        return "Fitness club: " + name +
               ", Working hours: " + workingHours +
               ", Website: " + website;
    }
}
