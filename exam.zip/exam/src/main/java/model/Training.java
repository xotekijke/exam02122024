package model;

public class Training {
    private String name;
    private double dailyPrice;
    private double weeklyPrice;
    private double monthlyPrice;

    public Training(String name, double dailyPrice, double weeklyPrice, double monthlyPrice) {
        this.name = name;
        this.dailyPrice = dailyPrice;
        this.weeklyPrice = weeklyPrice;
        this.monthlyPrice = monthlyPrice;
    }

    public String getName() {
        return name;
    }

    public double getDailyPrice() {
        return dailyPrice;
    }

    public double getWeeklyPrice() {
        return weeklyPrice;
    }

    public double getMonthlyPrice() {
        return monthlyPrice;
    }

    @Override
    public String toString() {
        return "Type of training: " + name +
               ", Price per day: " + dailyPrice + " $" +
               ", Price per week: " + weeklyPrice + " $" +
               ", Price per month: " + monthlyPrice + " $";
    }
}
