import service.FitnessClubService;
import service.TrainingService;

// 17. Фітнес-клуб. Види тренувань, ціна за один день заняття, тиждень, місяць, години роботи, сайт клубу
public class Main {
    public static void main(String[] args) {
        FitnessClubService clubService = new FitnessClubService();
        TrainingService trainingService = new TrainingService();

        trainingService.addTraining("Online training", 100, 600, 2000);
        trainingService.addTraining("Yoga", 150, 900, 3000);
        trainingService.addTraining("Swimming", 120, 750, 2500);

        clubService.displayClubInfo();
        trainingService.displayAllTrainings();
    }
}
